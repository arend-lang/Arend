package org.arend.typechecking.constructions;

import org.arend.core.context.binding.Binding;
import org.arend.core.context.binding.TypedBinding;
import org.arend.core.context.param.DependentLink;
import org.arend.core.definition.*;
import org.arend.core.expr.ClassCallExpression;
import org.arend.core.expr.Expression;
import org.arend.core.subst.Levels;
import org.arend.naming.reference.LocatedReferable;
import org.arend.term.concrete.Concrete;
import org.arend.typechecking.TypeCheckingTestCase;
import org.arend.typechecking.result.TypecheckingResult;
import org.arend.util.SingletonList;
import org.junit.Test;

import java.util.*;

import static org.arend.ExpressionFactory.*;
import static org.arend.Matchers.typeMismatchError;
import static org.arend.core.expr.ExpressionFactory.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DefCallTest extends TypeCheckingTestCase {
  private void test(Expression expected) {
    assertEquals(expected, ((FunctionDefinition) getDefinition("test")).getBody());
  }

  private void testDyn(Expression expected) {
    assertEquals(expected, ((FunctionDefinition) getDefinition("Test.test")).getBody());
  }

  private void testFI(Expression expected) {
    assertEquals(expected, ((FunctionDefinition) getDefinition("Test.test")).getBody());
  }

  private void testType(Expression expected, boolean isStatic) {
    FunctionDefinition definition = (FunctionDefinition) getDefinition(isStatic ? "test" : "Test.test");
    assertEquals(expected, definition.getResultType());
    assertEquals(expected, ((Expression) Objects.requireNonNull(definition.getBody())).getType());
  }

  private DependentLink getThis() {
    return getDefinition("test").getParameters();
  }

  private DependentLink getThisDyn() {
    return getDefinition("Test.test").getParameters();
  }

  private Expression getThisFI() {
    FunctionDefinition function = (FunctionDefinition) getDefinition("Test.test");
    return FieldCall(((ClassDefinition) getDefinition("Test")).getPersonalFields().getFirst(), Ref(function.getParameters()));
  }

  private ClassCallExpression makeClassCall(Definition definition, Expression impl) {
    ClassDefinition classDef = (ClassDefinition) definition;
    ClassCallExpression classCall = new ClassCallExpression(classDef, Levels.EMPTY, Collections.singletonMap(classDef.getNotImplementedFields().iterator().next(), impl), classDef.getSort(), classDef.getUniverseKind());
    classCall.updateHasUniverses();
    return classCall;
  }

  @Test
  public void funStatic() {
    typeCheckModule(
        "\\func f => 0\n" +
        "\\func test => f");
    test(FunCall((FunctionDefinition) getDefinition("f"), Levels.EMPTY));
  }

  @Test
  public void funDynamic() {
    typeCheckClass(
        "\\func f => 0\n" +
        "\\func test => f", "");
    testDyn(FunCall((FunctionDefinition) getDefinition("Test.f"), Levels.EMPTY, Ref(getThisDyn())));
  }

  /*
  @Test
  public void funDynamicFromInside() {
    typeCheckClass(
        "\\func f => 0\n" +
        "\\class Test {\n" +
        "  \\func test => f\n" +
        "}", "");
    testFI(FunCall((FunctionDefinition) getDefinition("f"), Levels.EMPTY, getThisFI()));
  }
  */

  @Test
  public void funDynamicError() {
    typeCheckModule("""
      \\class Test {
        \\func f => 0
      } \\where {
        \\func test : Nat => Test.f
      }
      """, 1);
  }

  @Test
  public void funStaticInside() {
    typeCheckModule("""
      \\class A \\where {
        \\class B \\where {
          \\func f => 0
        }
      }
      \\func test => A.B.f
      """);
    test(FunCall((FunctionDefinition) getDefinition("A.B.f"), Levels.EMPTY));
  }

  @Test
  public void funDynamicInside() {
    typeCheckClass("""
      \\class A \\where {
        \\class B \\where {
          \\func f => 0
        }
      }
      \\func test => A.B.f
      """, "");
    testDyn(FunCall((FunctionDefinition) getDefinition("Test.A.B.f"), Levels.EMPTY, Ref(getThisDyn())));
  }

  @Test
  public void funFieldStatic() {
    typeCheckModule("""
      \\class E {
        \\func f => 0
      }
      \\func test (e : E) => E.f {e}
      """);
    test(FunCall((FunctionDefinition) getDefinition("E.f"), Levels.EMPTY, Ref(getThis())));
  }

  @Test
  public void funFieldError() {
    typeCheckModule("""
      \\class E \\where {
        \\func f => 0
      }
      \\func test (e : E) => E.f {e}
      """, 1);
  }

  @Test
  public void funFieldDynamic() {
    typeCheckClass("""
      \\class E {
        \\func f => 0
      }
      \\func test (e : E) => E.f {e}
      """, "");
    testDyn(FunCall((FunctionDefinition) getDefinition("Test.E.f"), Levels.EMPTY, Ref(getThisDyn().getNext())));
  }

  @Test
  public void funFieldInside() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B \\where {
            \\func f => 0
          }
        }
      }
      \\func test (e : E) => E.A.B.f {e}
      """);
    test(FunCall((FunctionDefinition) getDefinition("E.A.B.f"), Levels.EMPTY, Ref(getThis())));
  }

  @Test
  public void funFieldInside2() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B {e : E} {
            \\func f => 0
          }
        }
      }
      \\func test (e : E) (b : E.A.B {e}) => E.A.B.f {b}
      """);
    test(FunCall((FunctionDefinition) getDefinition("E.A.B.f"), Levels.EMPTY, Ref(getThis().getNext())));
  }

  @Test
  public void funFieldInsideError() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B {
            \\func f => 0
          }
        }
      }
      \\func test (e : E) => E.A.B.f {e}
      """, 1);
  }

  @Test
  public void funFieldInsideError2() {
    typeCheckModule("""
      \\class E {
        \\class A {
          \\class B \\where {
            \\func f => 0
          }
        }
      }
      \\func test (e : E) => E.A.B.f {e}
      """, 1);
  }

  @Test
  public void conStatic() {
    typeCheckModule(
        "\\data D | c\n" +
        "\\func test => c");
    test(ConCall((Constructor) getDefinition("D.c"), Levels.EMPTY, Collections.emptyList()));
  }

  @Test
  public void dataStatic() {
    typeCheckModule(
        "\\data D | c\n" +
        "\\func test => D.c");
    test(ConCall((Constructor) getDefinition("D.c"), Levels.EMPTY, Collections.emptyList()));
  }

  @Test
  public void data2Static() {
    typeCheckModule(
        "\\data D (x : Nat) (y : Nat -> Nat) | c\n" +
        "\\func test => D.c {0} {\\lam _ => 1}");
    List<Expression> dataTypeArgs = Arrays.asList(Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    test(ConCall((Constructor) getDefinition("D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("D"), Levels.EMPTY, dataTypeArgs), true);
  }

  @Test
  public void conDynamic() {
    typeCheckClass(
        "\\data D | c\n" +
        "\\func test => c", "");
    testDyn(ConCall((Constructor) getDefinition("Test.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThisDyn()))));
  }

  /*
  @Test
  public void conDynamicFromInside() {
    typeCheckClass(
        "\\data D | c\n" +
        "\\class Test {\n" +
        "  \\func test => c\n" +
        "}", "");
    testFI(ConCall((Constructor) getDefinition("c"), Levels.EMPTY, new SingletonList<>(getThisFI())));
  }
  */

  @Test
  public void dataDynamic() {
    typeCheckClass(
        "\\data D | c\n" +
        "\\func test => D.c", "");
    testDyn(ConCall((Constructor) getDefinition("Test.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThisDyn()))));
  }

  /*
  @Test
  public void dataDynamicFromInside() {
    typeCheckClass(
        "\\data D | c\n" +
        "\\class Test {\n" +
        "  \\func test => D.c\n" +
        "}", "");
    testFI(ConCall((Constructor) getDefinition("c"), Levels.EMPTY, new SingletonList<>(getThisFI())));
  }
  */

  @Test
  public void data2Dynamic() {
    typeCheckClass(
        "\\data D (x : Nat) (y : Nat -> Nat) | c\n" +
        "\\func test => D.c {_} {0} {\\lam _ => 1}", "");
    List<Expression> dataTypeArgs = Arrays.asList(Ref(getThisDyn()), Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    testDyn(ConCall((Constructor) getDefinition("Test.D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("Test.D"), Levels.EMPTY, dataTypeArgs), false);
  }

  @Test
  public void data3Dynamic() {
    typeCheckClass(
      "\\func test => D.c {_} {path (\\lam _ => 0)}",
      "\\data D {x : Nat} (p : x = 0) | c");
  }

  /*
  @Test
  public void data2DynamicFromInside() {
    typeCheckClass(
        "\\data D (x : Nat) (y : Nat -> Nat) | c\n" +
        "\\class Test {\n" +
        "  \\func test => D.c {0} {\\lam _ => 1}\n" +
        "}", "");
    List<Expression> dataTypeArgs = Arrays.asList(getThisFI(), Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    testFI(ConCall((Constructor) getDefinition("c"), Levels.EMPTY, dataTypeArgs));
  }
  */

  @Test
  public void conDynamicError() {
    typeCheckModule("""
      \\class Test {
        \\data D | c
      } \\where {
        \\func test : Test.D => Test.c
      }
      """, 2);
  }

  @Test
  public void dataDynamicError() {
    typeCheckModule("""
      \\class Test {
        \\data D | c
      } \\where {
        \\func test : Test.D => Test.D.c
      }
      """, 2);
  }

  @Test
  public void conStaticInside() {
    typeCheckModule("""
      \\class A \\where {
        \\class B \\where {
          \\data D | c
        }
      }
      \\func test => A.B.c
      """);
    test(ConCall((Constructor) getDefinition("A.B.D.c"), Levels.EMPTY, Collections.emptyList()));
  }

  @Test
  public void dataStaticInside() {
    typeCheckModule("""
      \\class A \\where {
        \\class B \\where {
          \\data D | c
        }
      }
      \\func test => A.B.D.c
      """);
    test(ConCall((Constructor) getDefinition("A.B.D.c"), Levels.EMPTY, Collections.emptyList()));
  }

  @Test
  public void data2StaticInside() {
    typeCheckModule("""
      \\class A \\where {
        \\class B \\where {
          \\data D (x : Nat) (y : Nat -> Nat) | c
        }
      }
      \\func test => A.B.D.c {0} {\\lam _ => 1}
      """);
    List<Expression> dataTypeArgs = Arrays.asList(Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    test(ConCall((Constructor) getDefinition("A.B.D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("A.B.D"), Levels.EMPTY, dataTypeArgs), true);
  }

  @Test
  public void conDynamicInside() {
    typeCheckClass("""
      \\class A \\where {
        \\class B \\where {
          \\data D | c
        }
      }
      \\func test => A.B.c
      """, "");
    testDyn(ConCall((Constructor) getDefinition("Test.A.B.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThisDyn()))));
  }

  @Test
  public void dataDynamicInside() {
    typeCheckClass("""
      \\class A \\where {
        \\class B \\where {
          \\data D | c
        }
      }
      \\func test => A.B.D.c
      """, "");
    testDyn(ConCall((Constructor) getDefinition("Test.A.B.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThisDyn()))));
  }

  @Test
  public void data2DynamicInside() {
    typeCheckClass("""
      \\class A \\where {
        \\class B \\where {
          \\data D (x : Nat) (y : Nat -> Nat) | c
        }
      }
      \\func test => A.B.D.c {_} {0} {\\lam _ => 1}
      """, "");
    List<Expression> dataTypeArgs = Arrays.asList(Ref(getThisDyn()), Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    testDyn(ConCall((Constructor) getDefinition("Test.A.B.D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("Test.A.B.D"), Levels.EMPTY, dataTypeArgs), false);
  }

  @Test
  public void conFieldStatic() {
    typeCheckModule("""
      \\class E {
        \\data D | c
      }
      \\func test (e : E) => E.c {e}
      """);
    test(ConCall((Constructor) getDefinition("E.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThis()))));
  }

  @Test
  public void dataFieldStatic() {
    typeCheckModule("""
      \\class E {
        \\data D | c
      }
      \\func test (e : E) => E.D.c {e}
      """);
    test(ConCall((Constructor) getDefinition("E.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThis()))));
  }

  @Test
  public void data2FieldStatic() {
    typeCheckModule("""
      \\class E {
        \\data D (x : Nat) (y : Nat -> Nat) | c
      }
      \\func test (e : E) => E.D.c {e} {0} {\\lam _ => 1}
      """);
    List<Expression> dataTypeArgs = Arrays.asList(Ref(getThis()), Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    test(ConCall((Constructor) getDefinition("E.D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("E.D"), Levels.EMPTY, dataTypeArgs), true);
  }

  @Test
  public void conFieldError() {
    typeCheckModule("""
      \\class E \\where {
        \\data D | c
      }
      \\func test (e : E) => E.c {e}
      """, 1);
  }

  @Test
  public void dataFieldError() {
    typeCheckModule("""
      \\class E \\where {
        \\data D | c
      }
      \\func test (e : E) => E.D.c {e}
      """, 1);
  }

  @Test
  public void conFieldDynamic() {
    typeCheckClass("""
      \\class E {
        \\data D | c
      }
      \\func test (e : E) => E.c {e}
      """, "");
    testDyn(ConCall((Constructor) getDefinition("Test.E.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThisDyn().getNext()))));
  }

  @Test
  public void dataFieldDynamic() {
    typeCheckClass("""
      \\class E {
        \\data D | c
      }
      \\func test (e : E) => E.D.c {e}
      """, "");
    testDyn(ConCall((Constructor) getDefinition("Test.E.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThisDyn().getNext()))));
  }

  @Test
  public void data2FieldDynamic() {
    typeCheckClass("""
      \\class E {
        \\data D (x : Nat) (y : Nat -> Nat) | c
      }
      \\func test (e : E) => E.D.c {e} {0} {\\lam _ => 1}
      """, "");
    List<Expression> dataTypeArgs = Arrays.asList(Ref(getThisDyn().getNext()), Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    testDyn(ConCall((Constructor) getDefinition("Test.E.D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("Test.E.D"), Levels.EMPTY, dataTypeArgs), false);
  }

  @Test
  public void conFieldInside() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B \\where {
            \\data D | c
          }
        }
      }
      \\func test (e : E) => E.A.B.c {e}
      """);
    test(ConCall((Constructor) getDefinition("E.A.B.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThis()))));
  }

  @Test
  public void dataFieldInside() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B \\where {
            \\data D | c
          }
        }
      }
      \\func test (e : E) => E.A.B.D.c {e}
      """);
    test(ConCall((Constructor) getDefinition("E.A.B.D.c"), Levels.EMPTY, new SingletonList<>(Ref(getThis()))));
  }

  @Test
  public void data2FieldInside() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B \\where {
            \\data D (x : Nat) (y : Nat -> Nat) | c
          }
        }
      }
      \\func test (e : E) => E.A.B.D.c {e} {0} {\\lam _ => 1}
      """);
    List<Expression> dataTypeArgs = Arrays.asList(Ref(getThis()), Zero(), Lam(singleParam(null, Nat()), Suc(Zero())));
    test(ConCall((Constructor) getDefinition("E.A.B.D.c"), Levels.EMPTY, dataTypeArgs));
    testType(DataCall((DataDefinition) getDefinition("E.A.B.D"), Levels.EMPTY, dataTypeArgs), true);
  }

  @Test
  public void conFieldInsideError() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B {
            \\data D | c
          }
        }
      }
      \\func test (e : E) => E.A.B.c {e}
      """, 1);
  }

  @Test
  public void dataFieldInsideError() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B {
            \\data D | c
          }
        }
      }
      \\func test (e : E) => E.A.B.D.c {e}
      """, 1);
  }

  @Test
  public void conFieldInsideError2() {
    typeCheckModule("""
      \\class E {
        \\class A {
          \\class B \\where {
            \\data D | c
          }
        }
      }
      \\func test (e : E) => E.A.B.c {e}
      """, 1);
  }

  @Test
  public void dataFieldInsideError2() {
    typeCheckModule("""
      \\class E {
        \\class A {
          \\class B \\where {
            \\data D | c
          }
        }
      }
      \\func test (e : E) => E.A.B.D.c {e}
      """, 1);
  }

  @Test
  public void classStatic() {
    typeCheckModule(
        "\\class C\n" +
        "\\func test => C");
    test(new ClassCallExpression((ClassDefinition) getDefinition("C"), Levels.EMPTY));
  }

  /*
  @Test
  public void classDynamic() {
    typeCheckClass(
        "\\class C\n" +
        "\\func test => C", "");
    test(makeClassCall(getDefinition("C"), Ref(getThis())));
  }

  @Test
  public void classDynamicFromInside() {
    typeCheckClass(
        "\\class C\n" +
        "\\class Test {\n" +
        "  \\func test => C\n" +
        "}", "");
    testFI(makeClassCall(getDefinition("C"), getThisFI()));
  }
  */

  @Test
  public void classDynamicNoError() {
    typeCheckModule("""
      \\class Test {
        \\class C
      } \\where {
        \\func test : \\Prop => Test.C
      }
      """);
  }

  @Test
  public void classStaticInside() {
    typeCheckModule("""
      \\class A \\where {
        \\class B \\where {
          \\class C
        }
      }
      \\func test => A.B.C
      """);
    test(new ClassCallExpression((ClassDefinition) getDefinition("A.B.C"), Levels.EMPTY));
  }

  /*
  @Test
  public void classDynamicInside() {
    typeCheckClass(
        "\\class A \\where {\n" +
        "  \\class B \\where {\n" +
        "    \\class C\n" +
        "  }\n" +
        "}\n" +
        "\\func test => A.B.C", "");
    test(makeClassCall(getDefinition("A.B.C"), Ref(getThis())));
  }
  */

  @Test
  public void classFieldStatic() {
    typeCheckModule("""
      \\class E {
        \\class C {e : E}
      }
      \\func test (e : E) => E.C {e}
      """);
    test(makeClassCall(getDefinition("E.C"), Ref(getThis())));
  }

  @Test
  public void classFieldError() {
    typeCheckModule("""
      \\class E \\where {
        \\class C
      }
      \\func test (e : E) => E.C {e}
      """, 1);
  }

  @Test
  public void classFieldDynamic() {
    typeCheckClass("""
      \\class E {
        \\class C {e : E}
      }
      \\func test (e : E) => E.C {e}
      """, "");
    testDyn(makeClassCall(getDefinition("Test.E.C"), Ref(getThisDyn().getNext())));
  }

  @Test
  public void classFieldInside() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B \\where {
            \\class C {e : E}
          }
        }
      }
      \\func test (e : E) => E.A.B.C {e}
      """);
    test(makeClassCall(getDefinition("E.A.B.C"), Ref(getThis())));
  }

  @Test
  public void classFieldInsideError() {
    typeCheckModule("""
      \\class E {
        \\class A \\where {
          \\class B {
            \\class C
          }
        }
      }
      \\func test (e : E) => E.A.B.C {e}
      """, 1);
  }

  @Test
  public void classFieldInsideError2() {
    typeCheckModule("""
      \\class E {
        \\class A {
          \\class B \\where {
            \\class C
          }
        }
      }
      \\func test (e : E) => E.A.B.C {e}
      """, 1);
  }

  @Test
  public void local() {
    List<Binding> context = new ArrayList<>(1);
    context.add(new TypedBinding("x", Nat()));
    TypecheckingResult result = typeCheckExpr(context, "x", null);
    assertNotNull(result);
    assertEquals(Ref(context.getFirst()), result.expression);
  }

  @Test
  public void nonStaticTest() {
    typeCheckModule("\\class A { \\func x => 0 } \\func y {a : A} => A.x {a}");
  }

  @Test
  public void innerNonStaticTestError() {
    typeCheckModule("\\class A { \\class B { \\func x => 0 } } \\func y (a : A) => A.B.x {a}", 1);
    assertThatErrorsAre(typeMismatchError());
  }

  @Test
  public void innerNonStaticTestAcc() {
    typeCheckModule("\\class A { \\class B {a : A} { \\func x => 0 } } \\func y (a : A) (b : A.B {a}) => A.B.x {b}");
  }

  @Test
  public void innerNonStaticTest() {
    typeCheckModule("\\class A { \\class B \\where { \\func x => 0 } } \\func y (a : A) => A.B.x {a}");
  }

  @Test
  public void staticTest() {
    typeCheckModule("\\class A \\where { \\func x => 0 } \\func y : Nat => A.x");
  }

  @Test
  public void resolvedConstructorTest() {
    resolveNamesModule("""
      \\data TrP (A : \\Type) | inP A
      \\func isequiv {A B : \\Type0} (f : A -> B) => 0
      \\func inP-isequiv (P : \\Prop) => isequiv (inP {P})
      """);
    LocatedReferable inP = get("TrP.inP");
    Concrete.FunctionDefinition lastDef = (Concrete.FunctionDefinition) getConcrete("inP-isequiv");
    assertNotNull(lastDef);
    ((Concrete.ReferenceExpression) ((Concrete.AppExpression) ((Concrete.AppExpression) ((Concrete.TermFunctionBody) lastDef.getBody()).getTerm()).getArguments().getFirst().getExpression()).getFunction()).setReferent(inP);
    typeCheckModule();
  }
}
