package org.arend.typechecking.subexpr;

import org.arend.core.context.param.DependentLink;
import org.arend.core.expr.Expression;
import org.arend.term.concrete.Concrete;
import org.arend.typechecking.TypeCheckingTestCase;
import org.junit.Before;
import org.junit.Test;

import static org.arend.core.expr.ExpressionFactory.Fin;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class FindBindingTest extends TypeCheckingTestCase {
  @SuppressWarnings("unchecked")
  private static <T> T c(Object o) {
    return (T) o;
  }

  @Before
  public void initPrelude() {
    typeCheckModule("");
    incModification();
  }

  @Test
  public void multiParamLam() {
    Concrete.LamExpression xyx = (Concrete.LamExpression) resolveNamesExpr("\\lam x y => x");
    Expression pi = typeCheckExpr(resolveNamesExpr("\\Pi (x y : \\Type) -> \\Type"), null).expression;
    DependentLink link = FindBinding.visitLam(
        xyx.getParameters().get(1).getReferableList().getFirst(),
        c(xyx), c(typeCheckExpr(xyx, pi).expression)
    );
    assertNotNull(link);
    assertEquals("\\Type", link.getTypeExpr().toString());
  }

  @Test
  public void simpleLam() {
    Concrete.LamExpression xx = (Concrete.LamExpression) resolveNamesExpr("\\lam x => x");
    Expression pi = typeCheckExpr(resolveNamesExpr("\\Pi (x : \\Type) -> \\Type"), null).expression;
    DependentLink link = FindBinding.visitLam(
        xx.getParameters().getFirst().getReferableList().getFirst(),
        c(xx), c(typeCheckExpr(xx, pi).expression)
    );
    assertNotNull(link);
    assertEquals("\\Type", link.getTypeExpr().toString());
  }

  @Test
  public void pi() {
    Concrete.PiExpression xyx = (Concrete.PiExpression) resolveNamesExpr("\\Pi (A B : \\Type) (x y : A) -> B");
    DependentLink link = FindBinding.visitPi(
        xyx.getParameters().get(1).getReferableList().get(1),
        xyx, c(typeCheckExpr(xyx, null).expression)
    );
    assertNotNull(link);
    assertEquals("A", link.getTypeExpr().toString());
  }

  @Test
  public void let() {
    Concrete.LetExpression xyx = (Concrete.LetExpression) resolveNamesExpr("\\let | a => 114514 \\in a");
    Expression let = FindBinding.visitLetBind(
        xyx.getClauses().getFirst().getPattern().getData(),
        xyx, c(typeCheckExpr(xyx, null).expression));
    assertNotNull(let);
    assertEquals(Fin(114515), let);
  }

  @Test
  public void letParam() {
    Concrete.LetExpression xyx = (Concrete.LetExpression) resolveNamesExpr("\\let | f a => Nat.suc a \\in f 114514");
     DependentLink let = FindBinding.visitLetParam(
        xyx.getClauses().getFirst().getParameters().getFirst().getReferableList().getFirst(),
        xyx, c(typeCheckExpr(xyx, null).expression));
    assertNotNull(let);
    assertEquals("Nat", let.getTypeExpr().toString());
  }

  @Test
  public void sigma() {
    Concrete.SigmaExpression xyx = (Concrete.SigmaExpression) resolveNamesExpr("\\Sigma (A B : \\Type) (x y : A) A");
    Expression sig = typeCheckExpr(xyx, null).expression;
    {
      DependentLink link = FindBinding.visitSigma(
          xyx.getParameters().getFirst().getReferableList().getFirst(),
          xyx, c(sig)
      );
      assertNotNull(link);
      assertEquals("\\Type", link.getTypeExpr().toString());
    }
    {
      DependentLink link = FindBinding.visitSigma(
          xyx.getParameters().get(1).getReferableList().getFirst(),
          xyx, c(sig)
      );
      assertNotNull(link);
      assertEquals("A", link.getTypeExpr().toString());
    }
  }

  @Test
  public void caseExpr() {
    Concrete.CaseExpression case_ = (Concrete.CaseExpression) resolveNamesExpr("""
      \\case 114514 \\return Nat \\with {
        | suc x => 19260817
        | a => a
      }
      """);
    Expression core = typeCheckExpr(case_, null).expression;
    {
      Concrete.ConstructorPattern sucX = (Concrete.ConstructorPattern) case_.getClauses().getFirst().getPatterns().getFirst();
      DependentLink link = FindBinding.visitCase(
          sucX.getPatterns().getFirst().getData(),
          case_, c(core)
      );
      assertNotNull(link);
      assertEquals("Nat", link.getTypeExpr().toString());
      assertEquals("x", link.getName());
    }
    {
      DependentLink link = FindBinding.visitCase(
          case_.getClauses().get(1).getPatterns().getFirst().getData(),
          case_, c(core)
      );
      assertNotNull(link);
      assertEquals("Nat", link.getTypeExpr().toString());
      assertEquals("a", link.getName());
    }
  }
}